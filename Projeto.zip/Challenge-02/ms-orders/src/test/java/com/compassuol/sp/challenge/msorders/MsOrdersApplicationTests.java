package com.compassuol.sp.challenge.msorders;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsOrdersApplicationTests {

	@Test
	void contextLoads() {
	}
}

